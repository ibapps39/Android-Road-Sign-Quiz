### Android Road Sign Quiz

For this fourth Critical Thinking assignment you will create an app that tests the user’s knowledge of road signs. Display a random sign image and ask the user to select the sign’s name.

Visit http://mutcd.fhwa.dot.gov/ser-shs_millennium.htm for traffic sign images and information.

